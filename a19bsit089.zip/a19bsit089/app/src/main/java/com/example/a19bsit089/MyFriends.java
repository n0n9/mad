package com.example.a19bsit089;

import android.app.Activity;

public class MyFriends extends Activity {
}
